"""Window tracking package."""
